from datetime import datetime

import pytest
from conftest import get, send
from test_workflow import REFERENCE, process, question, submit

from app.database.session import session
from app.models import Submission

pytestmark = pytest.mark.postgres


def test_answer_accuracy_uses_latest_teacher_decisions_and_local_submission_dates(clients, school):
    teacher, student = clients["teacher"], clients["student"]
    item = question(teacher, school["id"])

    def answer(timestamp, *decisions):
        record = submit(student, item["id"], REFERENCE)
        process()
        analysis = get(teacher, f"/submissions/{record['id']}/result")["analysis"]
        # Every automatic result is HIGH_MATCH, but accuracy must follow teacher decisions.
        assert analysis["category"] == "HIGH_MATCH"
        for decision in decisions:
            send(teacher, f"/reviews/{analysis['id']}/{decision}", {}, 201)
        with session() as db, db.begin():
            db.get(Submission, record["id"]).created_at = datetime.fromisoformat(timestamp)
        return record

    answer("2026-11-17T10:00:00+00:00", "approve")
    revised = answer("2026-11-17T10:00:00+00:00", "reject", "approve")
    answer("2026-11-17T10:00:00+00:00", "partial")
    # 22:30 UTC belongs to the following day in Kyiv.
    answer("2026-11-16T22:30:00+00:00", "reject")
    answer("2026-11-17T10:00:00+00:00")
    answer("2026-11-16T10:00:00+00:00", "reject")
    answer("2026-11-15T10:00:00+00:00")
    answer("2026-10-10T10:00:00+00:00", "approve")
    # A repeated analysis must not erase the standing teacher decision or double count a submission.
    send(teacher, f"/submissions/{revised['id']}/reanalyze", expected=202)
    process()

    url = f"/reports/summary?course_id={school['id']}&date_from=2026-11-15&date_to=2026-11-18"
    report = get(teacher, url)
    days = {day["date"]: day for day in report["answer_accuracy"]}
    assert days["2026-11-17"] == {
        "date": "2026-11-17", "reviewed": 4, "correct": 2, "partial": 1, "incorrect": 1, "accuracy": 50,
    }
    assert days["2026-11-16"]["accuracy"] == 0
    assert days["2026-11-16"]["reviewed"] == 1
    assert days["2026-11-15"]["accuracy"] is None  # unreviewed is not incorrect
    assert days["2026-11-18"]["accuracy"] is None  # no submissions is not zero accuracy
    assert report["counts"]["submissions"] == 7
    assert report["counts"]["reviewed"] == 5
    assert get(clients["admin"], url)["answer_accuracy"] == report["answer_accuracy"]
    assert all(day["reviewed"] == 0 for day in get(clients["outsider"], url)["answer_accuracy"])
    get(student, url, 403)

    # The graph remains limited to the latest 30 days, even for a longer report filter.
    longer = get(teacher, "/reports/summary?date_from=2026-10-01&date_to=2026-11-18")["answer_accuracy"]
    assert len(longer) == 30
    assert longer[0]["date"] == "2026-10-20"
    assert sum(day["reviewed"] for day in longer) == 5


def test_answer_accuracy_is_empty_before_any_reviews(clients, school):
    report = get(clients["teacher"], "/reports/summary?date_from=2026-11-18&date_to=2026-11-18")
    assert report["answer_accuracy"] == [{
        "date": "2026-11-18", "reviewed": 0, "correct": 0, "partial": 0, "incorrect": 0, "accuracy": None,
    }]
