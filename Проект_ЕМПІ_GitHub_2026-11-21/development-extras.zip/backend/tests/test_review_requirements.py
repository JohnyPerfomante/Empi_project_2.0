from types import SimpleNamespace

import pytest
from conftest import get, send
from pydantic import SecretStr
from sqlalchemy import func, select

from app.database.session import session
from app.models import Course, Question, ReferenceAnswer, TeacherCourse, User
from app.nlp.analyzer import Candidate, analyze
from app.nlp.provider import TestProvider as FixtureProvider
from app.nlp.provider import Token
from app.schemas.analysis import AnalysisSettings
from app.schemas.catalog import ConceptIn, ConflictRule


def test_literal_concept_match_survives_context_dependent_hyphen_tokenisation():
    class SplitProvider(FixtureProvider):
        def morphology(self, text):
            if text == "ipv4-адреса":
                return ((Token("ipv4", "ipv4"), Token("адреса", "адреса")),)
            return ((Token("ipv4", "ipv4"), Token("-адреса", "-адрес")),)

    candidate = Candidate(
        1, "відома ipv4-адреса", "відома ipv4-адреса", [ConceptIn(concept="ipv4-адреса")], []
    )
    score = analyze(SplitProvider(), "відома ipv4-адреса", [candidate], [1.0], AnalysisSettings())
    assert score.concept_coverage == 1
    assert score.category.value == "HIGH_MATCH"


def test_another_reference_cannot_bypass_a_critical_conflict():
    answer = "система лише малює фотографії"
    rule = ConflictRule(phrase="малює фотографії", message="Це не призначення операційної системи.")
    candidates = [
        Candidate(1, "система керує ресурсами", "система керує ресурсами", [], [rule]),
        Candidate(2, answer, answer, [], []),
    ]
    outcome = analyze(FixtureProvider(), answer, candidates, [0.5, 1.0], AnalysisSettings())
    assert outcome.candidate.reference_id == 2
    assert outcome.final_similarity == pytest.approx(1)
    assert outcome.category.value == "LOW_MATCH"
    assert all(item["category"] == "LOW_MATCH" for item in outcome.comparisons)


def test_full_score_is_computed_for_every_reference_before_selection():
    answer = "процес виконує програму"
    candidates = [
        Candidate(1, "мережа передає пакети", "мережа передає пакети", [ConceptIn(concept="пакети")], []),
        Candidate(2, answer, answer, [ConceptIn(concept="програму")], []),
    ]
    result = analyze(FixtureProvider(), answer, candidates, [0.99, 0.90], AnalysisSettings())
    assert result.candidate.reference_id == 2
    assert result.final_similarity == pytest.approx(0.72 * 0.90 + 0.08 + 0.20)
    assert len(result.comparisons) == 2
    assert [item["selected"] for item in result.comparisons] == [False, True]
    assert result.comparisons[0]["missing"] == ["пакети"]


def test_weighted_formula_and_length_are_independent():
    candidate = Candidate(
        1,
        "альфа гама",
        "альфа гама",
        [
            ConceptIn(concept="альфа", importance_weight=2),
            ConceptIn(concept="дельта", importance_weight=1),
        ],
        [],
    )
    config = AnalysisSettings()
    results = [
        analyze(FixtureProvider(), answer, [candidate], [0.7], config)
        for answer in ["альфа бета", "альфа бета " * 30]
    ]
    expected = 0.72 * 0.7 + 0.08 / 3 + 0.20 * 2 / 3
    assert results[0].concept_coverage == pytest.approx(2 / 3)
    assert all(result.final_similarity == pytest.approx(expected) for result in results)


@pytest.mark.postgres
def test_two_distinct_references_required_for_publication(clients, school):
    teacher = clients["teacher"]
    body = {
        "course_id": school["id"],
        "text": "Для чого потрібна операційна система?",
        "status": "published",
        "references": [{"text": "ОС керує ресурсами комп’ютера."}],
    }
    send(teacher, "/questions", body, 422)
    body["status"] = "draft"
    question = send(teacher, "/questions", body, 201)
    path = f"/questions/{question['id']}"
    response = send(teacher, path, {"status": "published"}, 409, method="patch")
    assert "два" in response["error"]["message"]
    send(teacher, path + "/reference-answers", {"text": "ОС КЕРУЄ ресурсами комп’ютера!!!"}, 409)
    second = send(
        teacher,
        path + "/reference-answers",
        {"text": "Операційна система розподіляє пам’ять і процесорний час між програмами."},
        201,
    )
    send(teacher, path, {"status": "published"}, method="patch")
    assert get(teacher, path)["reference_count"] == 2
    send(teacher, f"/reference-answers/{second['id']}", body["references"][0], 409, method="patch")
    duplicate = {**body, "status": "published", "references": body["references"] * 2}
    send(teacher, "/questions", duplicate, 422)


@pytest.mark.postgres
def test_distinct_teachers_see_only_their_subjects(clients, school):
    admin, os_teacher, db_teacher = (clients[key] for key in ["admin", "teacher", "outsider"])
    specialty = get(admin, "/subjects")["items"][0]["specialty_id"]
    subject = send(admin, "/subjects", {"name": "Бази даних", "specialty_id": specialty}, 201)
    other = send(
        admin,
        "/courses",
        {"name": "Бази даних", "subject_id": subject["id"], "academic_year": "2026/2027"},
        201,
    )
    send(admin, f"/courses/{other['id']}/teachers", {"teacher_id": clients["outsider_id"]}, method="put")
    assert [row["id"] for row in get(os_teacher, "/courses")["items"]] == [school["id"]]
    assert [row["id"] for row in get(db_teacher, "/courses")["items"]] == [other["id"]]
    assert get(os_teacher, "/subjects")["items"][0]["name"] == "Операційні системи"
    assert get(db_teacher, "/subjects")["items"][0]["name"] == "Бази даних"
    get(os_teacher, f"/courses/{other['id']}", 404)
    get(db_teacher, f"/courses/{school['id']}", 404)
    get(db_teacher, f"/analysis/methodology?course_id={school['id']}", 404)
    assert get(clients["student"], f"/courses/{school['id']}")["teachers"] == ["Teacher"]
    body = {
        "course_id": school["id"],
        "text": "Питання чужої дисципліни",
        "references": [
            {"text": "Перший коректний еталон."},
            {"text": "Другий правильний варіант відповіді."},
        ],
    }
    send(db_teacher, "/questions", body, 404)


@pytest.mark.postgres
def test_methodology_has_sources_and_reproducible_example(clients):
    result = get(clients["teacher"], "/analysis/methodology")
    assert result["minimum_references"] == 2
    assert len(result["sources"]) >= 4 and len(result["formulas"]) == 5
    config, example = result["configuration"], result["example"]
    assert example["score"] == pytest.approx(
        config["semantic_weight"] * example["semantic"]
        + config["lexical_weight"] * example["lexical"]
        + config["concept_weight"] * example["coverage"]
    )


@pytest.mark.postgres
def test_demo_seed_has_two_references_and_seven_scoped_teachers(pg, monkeypatch):
    from scripts import seed_demo

    monkeypatch.setattr(
        seed_demo,
        "settings",
        lambda: SimpleNamespace(
            app_env="development", demo_password=SecretStr("Fixture-demo-password-2026!")
        ),
    )
    seed_demo.main()
    with session() as db, db.begin():
        legacy_teacher = db.scalar(select(User).where(User.email == "teacher@demo.edu.ua"))
        alg = db.scalar(select(Course).where(Course.name == seed_demo.TOPICS["alg"]))
        db.add(TeacherCourse(teacher_id=legacy_teacher.id, course_id=alg.id))
    seed_demo.main()
    with session() as db:
        assert db.scalar(select(func.count(Question.id))) == 50
        assert db.scalar(select(func.count(ReferenceAnswer.id))) == 100
        links = db.execute(
            select(TeacherCourse.teacher_id, TeacherCourse.course_id).where(TeacherCourse.active.is_(True))
        ).all()
        assert len(links) == 7 and len({row.teacher_id for row in links}) == 7
