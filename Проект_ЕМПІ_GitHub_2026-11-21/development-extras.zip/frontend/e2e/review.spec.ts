import { expect, test } from '@playwright/test'

async function login(page: import('@playwright/test').Page, handle = 'teacher') {
  await page.goto('/login')
  await page.getByLabel('Електронна пошта').fill(`${handle}@demo.edu.ua`)
  await page.getByLabel('Пароль', { exact: true }).fill(process.env.E2E_PASSWORD!)
  await page.getByRole('button', { name: 'Увійти', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Панель викладача' })).toBeVisible()
}

test('нове питання одразу має два різні обов’язкові еталони', async ({ page }) => {
  await login(page)
  await page.goto('/questions/new')
  const references = page.getByLabel('Текст еталона')
  await expect(references).toHaveCount(2)
  await expect(page.getByRole('button', { name: 'Зберегти питання' })).toBeDisabled()
  await references.nth(0).fill('ОС керує ресурсами комп’ютера.')
  await references.nth(1).fill('ОС КЕРУЄ ресурсами комп’ютера!!!')
  await expect(page.getByRole('button', { name: 'Зберегти питання' })).toBeDisabled()
  await references.nth(1).fill('Система розподіляє пам’ять та процесорний час між програмами.')
  await expect(page.getByRole('button', { name: 'Зберегти питання' })).toBeEnabled()
})

test('методика містить формули й наукові першоджерела на мобільному екрані', async ({ page }) => {
  await login(page)
  await page.setViewportSize({ width: 390, height: 844 })
  await page.goto('/methodology')
  await expect(page.getByRole('heading', { name: 'Методика перевірки', exact: true })).toBeVisible()
  await expect(page.getByRole('heading', { name: 'Вибір серед кількох еталонів', exact: true })).toBeVisible()
  await expect(page.getByRole('link', { name: /Sentence-BERT/ })).toHaveAttribute('href', 'https://aclanthology.org/D19-1410/')
  await expect(page.getByText(/Кількість символів не входить/)).toBeVisible()
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390)
})

for (const [handle, own, forbidden] of [
  ['teacher', 'Операційні системи', 'Алгоритми та структури даних'],
  ['teacher.alg', 'Алгоритми та структури даних', 'Операційні системи'],
]) {
  test(`викладач ${handle} бачить призначену дисципліну`, async ({ page }) => {
    await login(page, handle)
    await page.goto('/courses')
    await expect(page.getByRole('link', { name: own, exact: true })).toBeVisible()
    await expect(page.getByRole('link', { name: forbidden, exact: true })).toHaveCount(0)
    const response = await page.request.get('/api/v1/subjects')
    const data = await response.json()
    expect(data.items.map((item: { name: string }) => item.name)).toEqual([own])
  })
}
