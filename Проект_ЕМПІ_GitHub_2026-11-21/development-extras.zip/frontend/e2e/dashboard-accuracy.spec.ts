import { expect, test, type Page } from '@playwright/test'

async function login(page: Page) {
  await page.goto('/login')
  await page.getByLabel('Електронна пошта').fill(process.env.E2E_TEACHER_EMAIL ?? 'teacher@demo.edu.ua')
  await page.getByLabel('Пароль', { exact: true }).fill(process.env.E2E_PASSWORD!)
  await page.getByRole('button', { name: 'Увійти', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Панель викладача' })).toBeVisible()
}

test('графік використовує реальні рішення викладача із сервера', async ({ page }) => {
  await login(page)
  const response = await page.request.get('/api/v1/reports/summary')
  expect(response.ok()).toBeTruthy()
  const report = await response.json()
  const days = report.answer_accuracy as { correct: number; reviewed: number }[]
  expect(days.length).toBe(30)
  const reviewed = days.reduce((sum, day) => sum + day.reviewed, 0)
  const correct = days.reduce((sum, day) => sum + day.correct, 0)
  const panel = page.locator('section').filter({ has: page.getByRole('heading', { name: 'Точність відповідей студентів' }) })
  await expect(panel).toBeVisible()
  await expect(page.getByRole('heading', { name: 'Динаміка відповідей', exact: true })).toHaveCount(0)
  if (reviewed) {
    await expect(panel.getByText(`Правильних: ${correct} із ${reviewed} перевірених відповідей за період графіка`)).toBeVisible()
    await panel.getByText('Дані графіка', { exact: true }).click()
    await expect(panel.locator('tbody tr')).toHaveCount(days.filter(day => day.reviewed > 0).length)
  } else {
    await expect(panel.getByText(/ще немає перевірених відповідей/)).toBeVisible()
  }
})

test('відсотки, нульова точність та пропуски відображаються коректно на комп’ютері й телефоні', async ({ page }) => {
  await page.route('**/api/v1/reports/summary*', async route => {
    const response = await route.fetch()
    const report = await response.json()
    await route.fulfill({ response, json: { ...report, answer_accuracy: [
      { date: '2026-11-15', reviewed: 1, correct: 1, partial: 0, incorrect: 0, accuracy: 100 },
      { date: '2026-11-16', reviewed: 4, correct: 1, partial: 1, incorrect: 2, accuracy: 25 },
      { date: '2026-11-17', reviewed: 2, correct: 0, partial: 0, incorrect: 2, accuracy: 0 },
      { date: '2026-11-18', reviewed: 0, correct: 0, partial: 0, incorrect: 0, accuracy: null },
    ] } })
  })
  await login(page)
  const panel = page.locator('section').filter({ has: page.getByRole('heading', { name: 'Точність відповідей студентів' }) })
  await expect(panel.locator('.accuracy-summary strong')).toHaveText('28,6%')
  await expect(panel.getByRole('img').getByText('100%', { exact: true })).toBeVisible()
  await expect(panel.locator('.recharts-bar-rectangle path')).toHaveCount(3)
  await panel.locator('.recharts-bar-rectangle path').nth(1).hover()
  await expect(panel.locator('.accuracy-tooltip')).toContainText('25% правильних')
  await expect(panel.locator('.accuracy-tooltip')).toContainText('Частково правильні: 1')
  await panel.getByText('Дані графіка', { exact: true }).click()
  await expect(panel.locator('tbody tr')).toHaveCount(3)
  await expect(panel.locator('tbody tr').nth(2)).toContainText('0%')
  await page.setViewportSize({ width: 390, height: 844 })
  await expect(panel).toBeVisible()
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390)
})

test('відсутність рішень не показується як нульова точність', async ({ page }) => {
  await page.route('**/api/v1/reports/summary*', async route => {
    const response = await route.fetch()
    await route.fulfill({ response, json: { ...await response.json(), answer_accuracy: [
      { date: '2026-11-18', reviewed: 0, correct: 0, partial: 0, incorrect: 0, accuracy: null },
    ] } })
  })
  await login(page)
  const panel = page.locator('section').filter({ has: page.getByRole('heading', { name: 'Точність відповідей студентів' }) })
  await expect(panel.getByText(/ще немає перевірених відповідей/)).toBeVisible()
  await expect(panel.locator('.accuracy-summary')).toHaveCount(0)
  await expect(panel.locator('svg.recharts-surface')).toHaveCount(0)
})
