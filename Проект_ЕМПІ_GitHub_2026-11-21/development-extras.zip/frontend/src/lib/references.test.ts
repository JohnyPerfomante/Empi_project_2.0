import { describe, expect, it } from 'vitest'
import { hasTwoDistinctReferences } from './references'

describe('reference publication requirements', () => {
  it('accepts two different full references', () => {
    expect(hasTwoDistinctReferences([{ text: 'ОС керує ресурсами.' }, { text: 'Система запускає програми.' }])).toBe(true)
  })
  it.each([[], [{ text: 'ОС керує ресурсами.' }], [{ text: 'ОС керує ресурсами.' }, { text: '' }],
    [{ text: 'ОС керує ресурсами.' }, { text: '  ос КЕРУЄ ресурсами!!! ' }],
  ].map(references => ({ references })))('rejects an incomplete or duplicate reference set', ({ references }) => {
    expect(hasTwoDistinctReferences(references)).toBe(false)
  })
})
